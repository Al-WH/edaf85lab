package wash.control;

import actor.ActorThread;
import wash.io.WashingIO;

public class TemperatureController extends ActorThread<WashingMessage> {

    // TODO: add attributes

    public TemperatureController(WashingIO io) {
        // TODO
    }

    @Override
    public void run() {
        // TODO
    }
}
