package wash.control;

interface Settings {
    // simulation speed-up factor: 50 means the simulation is 50 times faster than
    // real time. Modify this as you wish.
    int SPEEDUP = 50;
}
