package wash.control;

import actor.ActorThread;
import wash.io.WashingIO;

public class WaterController extends ActorThread<WashingMessage> {

    // TODO: add attributes

    public WaterController(WashingIO io) {
        // TODO
    }

    @Override
    public void run() {
        // TODO
    }
}
